package com.primus;

import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.wildfly.swarm.Swarm;
import org.wildfly.swarm.datasources.DatasourcesFraction;
import org.wildfly.swarm.jaxrs.JAXRSArchive;
import org.wildfly.swarm.jpa.JPAFraction;
import org.wildfly.swarm.logging.LoggingFraction;

public class Main {

	public static void main(String[] args) throws Exception {

		Swarm swarm = new Swarm();
		
		swarm.fraction(LoggingFraction.createDebugLoggingFraction());
		swarm.fraction(getDatasourcesFraction());
		swarm.fraction(getJpaFraction());
		swarm.start();
		
		JAXRSArchive deployment = ShrinkWrap.create(JAXRSArchive.class);
		deployment.addAsLibrary(swarm.createDefaultDeployment());
		deployment.addAllDependencies();
		deployment.staticContent();
		swarm.deploy(deployment);
	}

	private static JPAFraction getJpaFraction() {
		return new JPAFraction().defaultDatasource("jboss/datasources/primusDS");
	}

	private static DatasourcesFraction getDatasourcesFraction() {
		return new DatasourcesFraction().jdbcDriver("org.postgresql", (d) -> {
			d.driverClassName("org.postgresql.Driver");
			d.xaDatasourceClass("org.postgresql.xa.PGXADataSource");
			d.driverModuleName("org.postgresql");
		}).dataSource("primusDS", (ds) -> {
			ds.driverName("org.postgresql");
			ds.connectionUrl("jdbc:postgresql://localhost:5432/primus");
			ds.userName("postgres");
			ds.password("postgres");
		});
	}
}
