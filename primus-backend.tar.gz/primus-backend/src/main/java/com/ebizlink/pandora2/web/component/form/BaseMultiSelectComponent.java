package com.ebizlink.pandora2.web.component.form;

import java.util.List;
import javax.faces.convert.Converter;
import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.web.component.BaseComponent;

@SuppressWarnings("serial")
public abstract class BaseMultiSelectComponent<T> extends BaseComponent implements Converter
{
	/**
	 */
	@Override
	public void clear() throws BaseException
	{
		super.clear();
		getSelected().clear();
	}

	/**
	 */
	public abstract List<T> getSelected();

	/**
	 */
	public abstract void setSelected(final List<T> selected);

	/**
	 */
	protected abstract List<T> getList();
}