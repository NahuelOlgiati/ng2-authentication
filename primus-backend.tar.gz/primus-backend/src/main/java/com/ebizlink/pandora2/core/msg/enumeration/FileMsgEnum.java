package com.ebizlink.pandora2.core.msg.enumeration;

public enum FileMsgEnum
{
	FILE_NOT_FOUND;
}