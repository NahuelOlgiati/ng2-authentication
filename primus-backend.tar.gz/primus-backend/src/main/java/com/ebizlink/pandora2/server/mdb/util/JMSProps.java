package com.ebizlink.pandora2.server.mdb.util;

public final class JMSProps
{
	public static final String QUEUE_TYPE = "javax.jms.Queue";
	public static final String TOPIC_TYPE = "javax.jms.Topic";
	public static final String CONNECTION_FACTORY = "ConnectionFactory";
}