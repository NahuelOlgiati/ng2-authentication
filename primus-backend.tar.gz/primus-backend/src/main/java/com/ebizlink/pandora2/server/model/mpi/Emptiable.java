package com.ebizlink.pandora2.server.model.mpi;

public interface Emptiable
{
	/**
	 */
	public abstract boolean isBlank();
}