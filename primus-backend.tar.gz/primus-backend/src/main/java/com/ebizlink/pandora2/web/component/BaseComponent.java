package com.ebizlink.pandora2.web.component;

import java.io.Serializable;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseComponent implements Serializable
{
	/**
	 */
	public BaseComponent()
	{
		try
		{
			init();
			initComponents();
			initProperties();
			clear();
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	protected void init() throws BaseException
	{
	}

	/**
	 */
	protected void initComponents() throws BaseException
	{
	}

	/**
	 */
	protected void initProperties() throws BaseException
	{
	}

	/**
	 */
	public void clear() throws BaseException
	{
	}
}