package com.ebizlink.pandora2.web.util;

import java.util.ArrayList;
import java.util.List;
import javax.faces.model.DataModel;
import javax.faces.model.SelectItem;
import com.ebizlink.pandora2.server.model.mpi.LabeledValued;

public final class JSFModelUtil
{
	/**
     */
	public static final <T extends LabeledValued<T>> List<SelectItem> getSelectItemList(final T... labeledValuedList)
	{
		final List<SelectItem> list = new ArrayList<SelectItem>();

		for (final LabeledValued<T> item : labeledValuedList)
		{
			list.add(new SelectItem(item.getValue(), item.getLabel()));
		}
		return list;
	}

	/**
	 * Warning: Don't use it with LazyDataModel.
	 */
	public static final <T extends Object, D extends DataModel<T>> List<T> getModelList(final D dataModel)
	{
		final List<T> list = new ArrayList<T>();
		for (final T item : dataModel)
		{
			list.add(item);
		}
		return list;
	}
}