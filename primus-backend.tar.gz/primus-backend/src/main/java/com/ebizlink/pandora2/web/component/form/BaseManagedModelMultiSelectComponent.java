package com.ebizlink.pandora2.web.component.form;

import java.util.ArrayList;
import java.util.List;
import com.ebizlink.pandora2.server.model.BaseModel;

@SuppressWarnings("serial")
public abstract class BaseManagedModelMultiSelectComponent<T extends BaseModel> extends BaseModelMultiSelectComponent<T>
{
	private List<T> modelList;

	/**
	 */
	@Override
	public List<T> getSelected()
	{
		if (modelList == null)
		{
			modelList = new ArrayList<T>();
		}
		return modelList;
	}

	/**
	 */
	@Override
	public void setSelected(List<T> selected)
	{
		this.modelList = selected;
	}
}