package com.ebizlink.pandora2.server.model.mpi;

public interface Labeled
{
	/**
	 */
	public abstract String getLabel();
}