package com.ebizlink.pandora2.server.model.mpi;

public interface Valued<T>
{
	/**
	 */
	public abstract T getValue();
}