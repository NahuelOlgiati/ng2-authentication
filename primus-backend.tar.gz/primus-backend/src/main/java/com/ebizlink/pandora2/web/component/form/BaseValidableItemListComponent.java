package com.ebizlink.pandora2.web.component.form;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.server.model.mpi.Validable;

@SuppressWarnings("serial")
public abstract class BaseValidableItemListComponent<T extends Validable> extends BaseItemListComponent<T>
{
	/**
	 */
	@Override
	protected void doValidAddItem() throws BaseException
	{
		getItem().valid();
	}
}