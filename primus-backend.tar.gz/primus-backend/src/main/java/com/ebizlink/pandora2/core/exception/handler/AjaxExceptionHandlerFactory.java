package com.ebizlink.pandora2.core.exception.handler;

import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerFactory;

public class AjaxExceptionHandlerFactory extends ExceptionHandlerFactory
{
	private ExceptionHandlerFactory parent;

	/**
	 */
	public AjaxExceptionHandlerFactory(ExceptionHandlerFactory parent)
	{
		this.parent = parent;
	}

	/**
	 */
	@Override
	public ExceptionHandler getExceptionHandler()
	{
		return new AjaxExceptionHandler(parent.getExceptionHandler());
	}
}