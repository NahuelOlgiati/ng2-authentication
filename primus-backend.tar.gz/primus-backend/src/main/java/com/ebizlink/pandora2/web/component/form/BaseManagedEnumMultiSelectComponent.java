package com.ebizlink.pandora2.web.component.form;

import java.util.ArrayList;
import java.util.List;
import com.ebizlink.pandora2.server.model.mpi.LabeledValued;

@SuppressWarnings("serial")
public abstract class BaseManagedEnumMultiSelectComponent<T extends Enum<T> & LabeledValued<T>> extends BaseEnumMultiSelectComponent<T>
{
	private List<T> enumList;

	/**
	 */
	@Override
	public List<T> getSelected()
	{
		if (enumList == null)
		{
			enumList = new ArrayList<T>();
		}
		return enumList;
	}

	/**
	 */
	@Override
	public void setSelected(List<T> selected)
	{
		this.enumList = selected;
	}
}