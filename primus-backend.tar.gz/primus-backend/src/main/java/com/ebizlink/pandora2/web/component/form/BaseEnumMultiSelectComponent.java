package com.ebizlink.pandora2.web.component.form;

import java.util.ArrayList;
import java.util.List;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.model.mpi.Labeled;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseEnumMultiSelectComponent<T extends Enum<T> & Labeled> extends BaseMultiSelectComponent<T>
{
	/**
	 */
	@Override
	public Object getAsObject(final FacesContext fc, final UIComponent uic, final String enumName)
	{
		T enumModel = null;
		try
		{
			if (enumName != null)
			{
				enumModel = Enum.valueOf(getEnumClass(), enumName);
			}
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
		return enumModel;
	}

	/**
	 */
	@Override
	@SuppressWarnings("unchecked")
	public String getAsString(final FacesContext fc, final UIComponent uic, final Object enumModel)
	{
		return !CompareUtil.isEmpty(enumModel) ? ((T) enumModel).name() : null;
	}

	/**
	 */
	public List<SelectItem> getEnumList()
	{
		final List<SelectItem> list = new ArrayList<SelectItem>();

		for (final T item : getList())
		{
			// In case this converter stops working, try: item.name() instead of item.
			list.add(new SelectItem(item, item.getLabel()));
		}
		return list;
	}

	/**
	 */
	protected abstract Class<T> getEnumClass();
}