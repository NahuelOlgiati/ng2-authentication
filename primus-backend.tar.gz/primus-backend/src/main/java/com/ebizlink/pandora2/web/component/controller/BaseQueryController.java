package com.ebizlink.pandora2.web.component.controller;

@SuppressWarnings("serial")
public abstract class BaseQueryController extends BaseController
{
}