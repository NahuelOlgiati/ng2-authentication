package com.ebizlink.pandora2.web.model.enumeration;

public enum RoleEnum
{
	BASIC,
	ADMIN;
}