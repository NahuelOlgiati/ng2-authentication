package com.ebizlink.pandora2.core.exception.handler;

import java.util.Iterator;

import javax.faces.FacesException;
import javax.faces.application.ProjectStage;
import javax.faces.context.ExceptionHandler;
import javax.faces.context.ExceptionHandlerWrapper;
import javax.faces.context.FacesContext;
import javax.faces.event.ExceptionQueuedEvent;

public class AjaxExceptionHandler extends ExceptionHandlerWrapper
{
	private ExceptionHandler wrapped;

	/**
	 */
	public AjaxExceptionHandler(ExceptionHandler exception)
	{
		this.wrapped = exception;
	}

	/**
	 */
	@Override
	public ExceptionHandler getWrapped()
	{
		return wrapped;
	}

	/**
	 */
	@Override
	public void handle() throws FacesException
	{
		handleAjaxException(FacesContext.getCurrentInstance(), ProjectStage.Production);
		this.wrapped.handle();
	}

	/**
	 */
	protected void handleAjaxException(FacesContext context, ProjectStage projectStage)
	{
		if (context == null || !context.getApplication().getProjectStage().equals(projectStage) || !context.getPartialViewContext().isAjaxRequest())
		{
			return;
		}

		Iterator<ExceptionQueuedEvent> unhandledExceptionQueuedEvents = getUnhandledExceptionQueuedEvents().iterator();

		if (!unhandledExceptionQueuedEvents.hasNext())
		{
			return;
		}

		unhandledExceptionQueuedEvents.remove();
		while (unhandledExceptionQueuedEvents.hasNext())
		{
			unhandledExceptionQueuedEvents.next();
			unhandledExceptionQueuedEvents.remove();
		}
	}
}