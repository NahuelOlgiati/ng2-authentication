package com.ebizlink.pandora2.server.model.mpi;

import java.util.List;
import com.ebizlink.pandora2.web.component.DetailData;

public interface Detailed
{
	/**
	 */
	public abstract List<DetailData> getDetailList();
}
