package com.ebizlink.pandora2.web.component.form;

import com.ebizlink.pandora2.server.model.BaseModel;

@SuppressWarnings("serial")
public abstract class BaseModelItemListComponent<T extends BaseModel> extends BaseValidableItemListComponent<T>
{
}