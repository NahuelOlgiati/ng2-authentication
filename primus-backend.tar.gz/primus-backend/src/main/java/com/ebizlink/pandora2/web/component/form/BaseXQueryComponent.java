package com.ebizlink.pandora2.web.component.form;

import javax.faces.event.ActionEvent;
import javax.faces.model.DataModel;
import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.web.component.BaseComponent;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseXQueryComponent<T, DM extends DataModel<?>> extends BaseComponent
{
	private DM queryListDM;

	/**
	 */
	@Override
	public void clear() throws BaseException
	{
		super.clear();
		queryListDM = null;
	}

	/**
	 */
	public DM getQueryListDM()
	{
		return queryListDM;
	}

	/**
	 */
	public Boolean getLoaded()
	{
		return !CompareUtil.isEmpty(getQueryListDM());
	}

	/**
	 */
	public void query(ActionEvent actionEvent)
	{
		try
		{
			doBeforeQuery();
			queryListDM = getNewQueryListDM();
			doAfterQuery();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	protected void doBeforeQuery() throws BaseException
	{
	}

	/**
	 */
	protected void doAfterQuery() throws BaseException
	{
	}

	protected abstract DM getNewQueryListDM() throws BaseException;
}