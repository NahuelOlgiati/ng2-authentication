package com.ebizlink.pandora2.web.component.form;

import javax.faces.event.ActionEvent;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.web.component.BaseComponent;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseDetailComponent extends BaseComponent
{
	/**
	 */
	public void load(ActionEvent actionEvent)
	{
		try
		{
			doLoad();
			doAfterLoad();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	protected abstract void doLoad() throws BaseException;

	/**
	 */
	protected void doAfterLoad() throws BaseException
	{
	}

	/**
	 */
	public abstract Boolean getLoaded();
}