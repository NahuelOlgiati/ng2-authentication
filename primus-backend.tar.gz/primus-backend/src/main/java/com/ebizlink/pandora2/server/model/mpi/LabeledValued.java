package com.ebizlink.pandora2.server.model.mpi;

public interface LabeledValued<T> extends Labeled, Valued<T>
{
}