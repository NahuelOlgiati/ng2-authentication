package com.ebizlink.pandora2.web.model.menu;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.web.util.JAASUtil;

@SuppressWarnings("serial")
public final class MenuItemRol extends MenuEntry implements Serializable
{
	private String value;
	private String image;
	private String notes;
	private String roles;
	private Boolean rendered;

	/**
	 */
	public MenuItemRol(String label, String value, String image, String notes, String roles)
	{
		super(label);
		this.value = value;
		this.image = image;
		this.notes = notes;
		this.roles = roles;
		this.rendered = null;
	}

	/**
	 */
	public final String getValue()
	{
		return value;
	}

	/**
	 */
	public final void setValue(String value)
	{
		this.value = value;
	}

	/**
	 */
	public final String getImage()
	{
		return image;
	}

	/**
	 */
	public final void setImage(String image)
	{
		this.image = image;
	}

	/**
	 */
	public final String getNotes()
	{
		return notes;
	}

	/**
	 */
	public final void setNotes(String notes)
	{
		this.notes = notes;
	}

	/**
	 */
	public final String getRoles()
	{
		return roles;
	}

	/**
	 */
	public final void setRoles(String roles)
	{
		this.roles = roles;
	}

	/**
	 */
	public final List<String> getRoleList()
	{
		final StringTokenizer st = new StringTokenizer(getRoles(), ",");
		final List<String> roleList = new ArrayList<String>();

		while (st.hasMoreElements())
		{
			roleList.add(st.nextElement().toString());
		}
		return roleList;
	}

	/**
	 */
	@Override
	public boolean isLeaf()
	{
		return true;
	}

	/**
	 */
	@Override
	public boolean getRendered()
	{
		if (CompareUtil.isEmpty(this.rendered))
		{
			if (JAASUtil.isAdmin() || JAASUtil.inRole(getRoleList()))
			{
				this.rendered = Boolean.TRUE;
			}
			else
			{
				this.rendered = Boolean.FALSE;
			}
		}

		return this.rendered.booleanValue();
	}
}