package com.ebizlink.pandora2.server.model.mpi;

public interface Manageable
{
	/**
	 */
	public abstract boolean isNew();

	/**
	 */
	public abstract boolean isPersisted();
}