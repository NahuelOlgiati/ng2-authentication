package com.ebizlink.pandora2.server.model.mpi;

public interface Selectable
{
	/**
	 */
	public abstract boolean getSelectable();
}