package com.ebizlink.pandora2.server.model.mpi;

public interface Describable
{
	/**
	 */
	public abstract String getFullDescription();
}