package com.ebizlink.pandora2.web.component.form;

import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.web.component.BaseComponent;

@SuppressWarnings("serial")
public abstract class BaseTriBooleanSateComponent extends BaseComponent
{
	/**
	 */
	public Integer getValue()
	{
		final Boolean booleanState = getBooleanState();
		if (CompareUtil.isEmpty(booleanState))
			return 0;
		else if (booleanState)
			return 1;
		else
			return 2;
	}

	/**
	 */
	public void setValue(Integer key)
	{
		switch (key)
		{
		case 1:
			setBooleanState(Boolean.TRUE);
			break;
		case 2:
			setBooleanState(Boolean.FALSE);
			break;
		default:
			setBooleanState(null);
			break;
		}
	}

	/**
	 */
	public abstract Boolean getBooleanState();

	/**
	 */
	public abstract void setBooleanState(Boolean booleanState);
}