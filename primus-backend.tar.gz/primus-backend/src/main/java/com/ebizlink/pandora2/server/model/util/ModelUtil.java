package com.ebizlink.pandora2.server.model.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.faces.model.DataModel;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.model.BaseModel;
import com.ebizlink.pandora2.server.model.BaseSimpleModel;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.XppDriver;

public final class ModelUtil
{
	/**
	 */
	public static final <T> boolean hasDuplicates(final Collection<T> collection)
	{
		if (!CompareUtil.isEmpty(collection))
		{
			final Set<T> set = new HashSet<T>(collection);

			if (set.size() < collection.size())
			{
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	/**
	 */
	@SuppressWarnings("unchecked")
	public static final <T> T getCopy(final T model)
	{
		final XStream x = new XStream(new XppDriver());
		return (T) x.fromXML(x.toXML(model));
	}

	/**
	 */
	public static final List<Long> getModelIDList(final BaseModel... baseModels)
	{
		final List<Long> modelIDList = new ArrayList<Long>();
		if (!CompareUtil.isEmpty(baseModels))
		{
			for (final BaseModel b : baseModels)
			{
				modelIDList.add(b.getID());
			}
		}
		return modelIDList;
	}

	/**
	 */
	@SuppressWarnings("unchecked")
	public static final <T> List<T> getModelList(final DataModel<T> dm)
	{
		return (List<T>) dm.getWrappedData();
	}

	/**
	 */
	public static final List<String> getFullDescriptionList(final BaseModel... baseModels)
	{
		final ArrayList<String> fullDescriptionList = new ArrayList<String>();

		if (!CompareUtil.isEmpty(baseModels))
		{
			for (final BaseModel b : baseModels)
			{
				fullDescriptionList.add(b.getFullDescription());
			}
		}
		return fullDescriptionList;
	}

	/**
	 */
	public static final List<String> getDescriptionList(final BaseSimpleModel... baseSimpleModels)
	{
		final ArrayList<String> descriptionList = new ArrayList<String>();

		if (!CompareUtil.isEmpty(baseSimpleModels))
		{
			for (final BaseSimpleModel b : baseSimpleModels)
			{
				descriptionList.add(b.getDescription());
			}
		}
		return descriptionList;
	}
}