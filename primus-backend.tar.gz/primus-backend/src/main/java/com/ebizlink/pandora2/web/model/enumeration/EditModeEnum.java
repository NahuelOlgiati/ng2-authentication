package com.ebizlink.pandora2.web.model.enumeration;

public enum EditModeEnum
{
	ADDING,
	EDITING,
	NONE;

	/**
	 */
	public final Boolean getInEditionMode()
	{
		return !this.equals(NONE);
	}
}