package com.ebizlink.pandora2.web.util;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.context.FacesContext;
import com.ebizlink.pandora2.core.msg.enumeration.ErrorMsgEnum;
import com.ebizlink.pandora2.core.msg.enumeration.LogMsgEnum;
import com.ebizlink.pandora2.core.msg.util.PM;

public final class JSFUtil
{
	/**
	 */
	private static final void addMessage(final Severity severity, final String summary, final String detail)
	{
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(severity, summary, detail));
	}

	/**
	 */
	public static final void info(final String message)
	{
		addMessage(FacesMessage.SEVERITY_INFO, PM.getMe().getMsg(LogMsgEnum.INFO), message);
	}

	/**
	 */
	public static final void warn(final String message)
	{
		addMessage(FacesMessage.SEVERITY_WARN, PM.getMe().getMsg(LogMsgEnum.WARN), message);
	}

	/**
	 */
	public static final void error(final String message)
	{
		addMessage(FacesMessage.SEVERITY_ERROR, PM.getMe().getMsg(LogMsgEnum.ERROR), message);
	}

	/**
	 */
	public static final void error(final List<String> messageList)
	{
		for (final String message : messageList)
		{
			error(message);
		}
	}

	/**
	 */
	public static final void fatal()
	{
		addMessage(FacesMessage.SEVERITY_FATAL, PM.getMe().getMsg(LogMsgEnum.FATAL), PM.getMe().getMsg(ErrorMsgEnum.GENERAL));
	}

	/**
	 */
	public static final void fatal(String message)
	{
		addMessage(FacesMessage.SEVERITY_FATAL, PM.getMe().getMsg(LogMsgEnum.FATAL), message);
	}
}