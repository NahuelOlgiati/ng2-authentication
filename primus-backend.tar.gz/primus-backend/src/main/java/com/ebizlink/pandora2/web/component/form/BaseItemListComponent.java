package com.ebizlink.pandora2.web.component.form;

import java.util.List;

import javax.faces.event.ActionEvent;
import javax.faces.model.ListDataModel;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.model.util.ModelUtil;
import com.ebizlink.pandora2.web.component.BaseComponent;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseItemListComponent<T> extends BaseComponent
{
	private ListDataModel<T> itemListDM;
	private List<T> itemList;
	private T item;
	private int itemIndex;

	/**
	 */
	@Override
	public void clear() throws BaseException
	{
		super.clear();
		doClear();
		doClearItem();
	}

	/**
	 */
	public ListDataModel<T> getItemListDM()
	{
		return itemListDM;
	}

	/**
	 */
	public List<T> getItemList()
	{
		return itemList;
	}

	/**
	 */
	public T getItem()
	{
		return item;
	}

	/**
	 */
	protected final void setItem(final T item)
	{
		this.item = item;
	}

	/**
	 */
	public int getItemIndex()
	{
		return itemIndex;
	}

	/**
	 */
	protected final void setItemIndex(final int itemIndex)
	{
		this.itemIndex = itemIndex;
	}

	/**
	 */
	public void bind(final List<T> itemList) throws BaseException
	{
		itemListDM = new ListDataModel<T>(this.itemList = itemList);
		doClearItem();
		doAfterClearItem();
	}

	/**
	 */
	public void clearItem(ActionEvent actionEvent)
	{
		try
		{
			doClearItem();
			doAfterClearItem();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
			
		}
	}

	/**
	 */
	public void addItem(ActionEvent actionEvent)
	{
		try
		{
			doBeforeValidAddItem();
			doValidAddItem();
			doAddItem();
			doAfterAddItem();
			doClearItem();
			doAfterClearItem();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	public void editItem(ActionEvent actionEvent)
	{
		try
		{
			doEditItem();
			doAfterEditItem();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	public void deleteItem(ActionEvent actionEvent)
	{
		try
		{
			doBeforeDeleteItem();
			doDeleteItem();
			doAfterDeleteItem();
			doClearItem();
			doAfterClearItem();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	private final void doClear()
	{
		itemListDM = new ListDataModel<T>();
		itemList = null;
	}

	/**
	 */
	private final void doClearItem()
	{
		item = getNewItem();
		itemIndex = -1;
	}

	/**
	 */
	private final void doAddItem()
	{
		if (CompareUtil.isNegative(getItemIndex()))
		{
			getItemList().add(getItem());
		}
		else
		{
			getItemList().set(getItemIndex(), getItem());
		}
	}

	/**
	 */
	private final void doEditItem()
	{
		item = ModelUtil.getCopy(getItemList().get(itemIndex = getItemListDM().getRowIndex()));
	}

	/**
	 */
	private final void doDeleteItem()
	{
		getItemList().remove(getItemListDM().getRowIndex());
	}

	/**
	 */
	protected void doBeforeValidAddItem() throws BaseException
	{
	}

	/**
	 */
	protected abstract void doValidAddItem() throws BaseException;

	/**
	 */
	protected void doAfterAddItem() throws BaseException
	{
	}

	/**
	 */
	protected void doAfterEditItem() throws BaseException
	{
	}

	/**
	 */
	protected void doBeforeDeleteItem() throws BaseException
	{
	}

	/**
	 */
	protected void doAfterDeleteItem() throws BaseException
	{
	}

	/**
	 */
	protected void doAfterClearItem() throws BaseException
	{
	}

	/**
	 */
	protected abstract T getNewItem();
}