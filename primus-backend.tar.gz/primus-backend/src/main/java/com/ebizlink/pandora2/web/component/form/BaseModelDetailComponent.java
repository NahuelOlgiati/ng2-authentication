package com.ebizlink.pandora2.web.component.form;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.ejb.BaseManager;
import com.ebizlink.pandora2.server.model.BaseModel;

@SuppressWarnings("serial")
public abstract class BaseModelDetailComponent<T extends BaseModel> extends BaseDetailComponent
{
	protected T model;

	/**
	 */
	@Override
	public void clear() throws BaseException
	{
		super.clear();
		model = null;
	}

	/**
	 */
	public T getModel()
	{
		if (model == null)
		{
			model = getNewModel();
		}
		return model;
	}

	/**
	 */
	@Override
	public Boolean getLoaded()
	{
		return !CompareUtil.isEmpty(getModel().getID());
	}

	/**
	 */
	@Override
	public void doLoad() throws BaseException
	{
		if (CompareUtil.isEmpty(getModel()) || !getModel().getID().equals(getModelID()))
		{
			model = getDetailManager().getFULL(getModelID());
		}
	}

	/**
	 */
	protected abstract BaseManager<T> getDetailManager();

	/**
	 */
	protected abstract T getNewModel();

	/**
	 */
	protected abstract Long getModelID() throws BaseException;
}