package com.ebizlink.pandora2.web.component.controller;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.msg.enumeration.DatabaseMsgEnum;
import com.ebizlink.pandora2.core.msg.util.PM;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.ejb.BasePersistenceManager;
import com.ebizlink.pandora2.server.exception.ValidationException;
import com.ebizlink.pandora2.server.model.BaseModel;

@SuppressWarnings("serial")
public abstract class BaseManagedCrudController<T extends BaseModel, M extends BasePersistenceManager<T>> extends BaseCrudController
{
	private T model;

	/**
	 */
	@Override
	public void clear() throws BaseException
	{
		super.clear();
		model = getNewModel();
	}

	/**
	 */
	public T getModel()
	{
		if (model == null)
		{
			model = getNewModel();
		}
		return model;
	}

	/**
	 */
	public void setModel(T model)
	{
		this.model = model;
	}

	/**
	 */
	@Override
	protected void doAdd() throws BaseException
	{
		model = getNewModel();
	}

	/**
	 */
	@Override
	protected void doEdit() throws BaseException
	{
		if (CompareUtil.isEmpty(model = getCrudManager().getFULL(getModel().getID())))
		{
			throw new ValidationException(PM.getMe().getMsg(DatabaseMsgEnum.RECORD_NOT_FOUND));
		}
	}

	/**
	 */
	@Override
	protected void doDelete() throws BaseException
	{
		getCrudManager().delete(getModel().getID());
	}

	/**
	 */
	@Override
	protected void doSave() throws BaseException
	{
		getCrudManager().save(getModel());
	}

	/**
	 */
	@Override
	protected void doCancel() throws BaseException
	{
	}

	/**
	 */
	protected abstract M getCrudManager();

	/**
	 */
	protected abstract T getNewModel();
}