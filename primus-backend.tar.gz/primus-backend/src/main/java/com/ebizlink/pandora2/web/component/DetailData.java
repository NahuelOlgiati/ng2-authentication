package com.ebizlink.pandora2.web.component;

import java.util.ArrayList;
import java.util.List;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.model.mpi.Emptiable;

public class DetailData implements Emptiable
{
	private final String key;
	private final String value;
	private List<String> values;
	private Boolean listable;

	/**
	 */
	public DetailData(final String key, final String value)
	{
		this.key = key;
		this.value = value;
		this.values = null;
		this.listable = Boolean.FALSE;
	}

	/**
	 */
	public DetailData(final String key)
	{
		this(key, null);
	}

	/**
	 */
	public String getKey()
	{
		return key;
	}

	/**
	 */
	public String getValue()
	{
		return value;
	}

	/**
	 */
	public List<String> getValues()
	{
		if (values == null)
		{
			values = new ArrayList<String>();
		}
		return values;
	}

	/**
	 */
	public Boolean getListable()
	{
		return listable;
	}

	/**
	 */
	public void setListable(Boolean listable)
	{
		this.listable = listable;
	}

	/**
	 */
	public void add(String value)
	{
		setListable(Boolean.TRUE);
		getValues().add(value);
	}

	/**
	 */
	public void addAll(List<String> values)
	{
		setListable(Boolean.TRUE);
		getValues().addAll(values);
	}

	/**
	 */
	@Override
	public boolean isBlank()
	{
		return CompareUtil.isEmpty(value) && CompareUtil.isEmpty(values);
	}
}