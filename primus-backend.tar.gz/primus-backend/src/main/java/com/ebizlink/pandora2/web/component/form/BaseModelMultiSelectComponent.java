package com.ebizlink.pandora2.web.component.form;

import java.util.List;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.model.BaseModel;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseModelMultiSelectComponent<T extends BaseModel> extends BaseMultiSelectComponent<T>
{
	/**
	 */
	@Override
	public Object getAsObject(final FacesContext fc, final UIComponent uic, final String modelID)
	{
		T model = null;
		try
		{
			if (!CompareUtil.isEmpty(modelID))
			{
				final Long id = Long.valueOf(modelID);

				for (final T t : getList())
				{
					if (id.equals(t.getID()))
					{
						model = t;
						break;
					}
				}
			}
		}
		catch (NumberFormatException n)
		{
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
		return model;
	}

	/**
	 */
	@Override
	@SuppressWarnings("unchecked")
	public String getAsString(final FacesContext fc, final UIComponent uic, final Object model)
	{
		return !CompareUtil.isEmpty(model) ? ((T) model).getID().toString() : null;
	}

	/**
	 */
	@Override
	public abstract List<T> getList();
}