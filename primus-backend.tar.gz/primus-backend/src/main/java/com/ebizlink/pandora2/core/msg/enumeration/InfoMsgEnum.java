package com.ebizlink.pandora2.core.msg.enumeration;

public enum InfoMsgEnum
{
	SUCCESS,
	FAILURE,
	CANCELED;
}