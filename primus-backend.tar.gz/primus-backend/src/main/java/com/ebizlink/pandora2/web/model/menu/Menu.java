package com.ebizlink.pandora2.web.model.menu;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("serial")
public final class Menu implements Serializable
{
	private List<MenuEntry> menuEntryList;

	/**
	 */
	public Menu(List<MenuEntry> menuEntryList)
	{
		this.menuEntryList = menuEntryList;
	}

	/**
	 */
	public final List<MenuEntry> getMenuEntryList()
	{
		return menuEntryList;
	}

	/**
	 */
	public final void setMenuEntryList(List<MenuEntry> menuEntryList)
	{
		this.menuEntryList = menuEntryList;
	}
}