package com.ebizlink.pandora2.web.model.menu;

import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class MenuEntry implements Serializable
{
	private String label;

	/**
	 */
	public MenuEntry(String label)
	{
		super();
		this.label = label;
	}

	/**
	 */
	public final String getLabel()
	{
		return label;
	}

	/**
	 */
	public final void setLabel(String label)
	{
		this.label = label;
	}

	/**
	 */
	public abstract boolean isLeaf();

	/**
	 */
	public abstract boolean getRendered();
}