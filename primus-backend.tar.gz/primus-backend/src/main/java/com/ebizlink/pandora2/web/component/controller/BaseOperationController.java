package com.ebizlink.pandora2.web.component.controller;

import javax.faces.event.ActionEvent;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.msg.enumeration.InfoMsgEnum;
import com.ebizlink.pandora2.core.msg.util.PM;
import com.ebizlink.pandora2.web.util.JSFUtil;

@SuppressWarnings("serial")
public abstract class BaseOperationController extends BaseController
{
	/**
	 */
	public void perform(ActionEvent actionEvent)
	{
		try
		{
			doBeforePerform();
			doPerform();
			doAfterPerform();
			clear();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	public void cancel(ActionEvent actionEvent)
	{
		try
		{
			doBeforeCancel();
			doCancel();
			doAfterCancel();
			clear();
		}
		catch (BaseException b)
		{
			JSFUtil.error(b.getMessages());
		}
		catch (Throwable t)
		{
			JSFUtil.fatal();
		}
	}

	/**
	 */
	protected abstract void doPerform() throws BaseException;

	/**
	 */
	protected void doCancel() throws BaseException
	{
	}

	/**
	 */
	protected void doBeforePerform() throws BaseException
	{
	}

	/**
	 */
	protected void doBeforeCancel() throws BaseException
	{
	}

	/**
	 */
	protected void doAfterPerform() throws BaseException
	{
		JSFUtil.info(PM.getMe().getMsg(InfoMsgEnum.SUCCESS));
	}

	/**
	 */
	protected void doAfterCancel() throws BaseException
	{
		JSFUtil.info(PM.getMe().getMsg(InfoMsgEnum.CANCELED));
	}
}