package com.ebizlink.pandora2.web.component.controller;

import java.io.IOException;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.web.component.BaseComponent;
import com.ebizlink.pandora2.web.util.JAASUtil;
import com.ebizlink.pandora2.web.util.JSFContextUtil;

@SuppressWarnings("serial")
public abstract class BaseController extends BaseComponent
{
	/**
	 */
	@Override
	protected final void init()
	{
		try
		{
			if (!CompareUtil.isEmpty(getViewRole()) && !getViewEnabled())
			{
				JSFContextUtil.redirect();
			}
		}
		catch (IOException i)
		{
			throw new RuntimeException(i);
		}
	}

	/**
	 */
	public Boolean getViewEnabled()
	{
		return JAASUtil.isAdmin() || JAASUtil.inRole(getViewRole());
	}

	/**
	 */
	protected abstract String getViewRole();
}