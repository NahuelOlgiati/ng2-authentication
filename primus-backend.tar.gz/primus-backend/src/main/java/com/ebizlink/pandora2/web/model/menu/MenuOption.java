package com.ebizlink.pandora2.web.model.menu;

import java.io.Serializable;
import java.util.List;
import com.ebizlink.pandora2.core.util.CompareUtil;

@SuppressWarnings("serial")
public final class MenuOption extends MenuEntry implements Serializable
{
	private List<MenuEntry> menuEntryList;
	private Boolean rendered;

	/**
	 */
	public MenuOption(String label, List<MenuEntry> menuEntryList)
	{
		super(label);
		this.menuEntryList = menuEntryList;
		this.rendered = null;
	}

	/**
	 */
	public List<MenuEntry> getMenuEntryList()
	{
		return menuEntryList;
	}

	/**
	 */
	public void setMenuEntryList(List<MenuEntry> menuEntryList)
	{
		this.menuEntryList = menuEntryList;
	}

	/**
	 */
	@Override
	public boolean isLeaf()
	{
		return false;
	}

	/**
	 */
	@Override
	public boolean getRendered()
	{
		if (CompareUtil.isEmpty(this.rendered))
		{
			rendered = Boolean.FALSE;

			for (int i = 0; i < this.menuEntryList.size(); i++)
			{
				rendered = rendered || new Boolean(this.menuEntryList.get(i).getRendered());
			}
		}

		return rendered.booleanValue();
	}
}