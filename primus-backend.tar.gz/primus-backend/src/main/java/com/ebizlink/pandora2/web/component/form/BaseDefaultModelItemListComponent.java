package com.ebizlink.pandora2.web.component.form;

import javax.faces.event.ActionEvent;
import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.server.model.BaseModel;

@SuppressWarnings("serial")
public abstract class BaseDefaultModelItemListComponent<T extends BaseModel> extends BaseModelItemListComponent<T>
{
	/**
	 */
	@Override
	protected void doAfterAddItem() throws BaseException
	{
		super.doAfterAddItem();

		if (getItemList().size() == 1)
		{
			doDefaultItem(getItemList().get(0));
		}
	}

	/**
	 */
	@Override
	protected void doAfterDeleteItem() throws BaseException
	{
		super.doAfterDeleteItem();

		final int size = getItemList().size();

		if (size == 0)
		{
			doDefaultItem(null);
		}
		else if (size == 1)
		{
			doDefaultItem(getItemList().get(0));
		}
		else if (!getItemList().contains(getDefault()))
		{
			doDefaultItem(getItemList().get(0));
		}
	}

	/**
	 */
	public void defaultItem(final ActionEvent actionEvent)
	{
		doDefaultItem(getItemListDM().getRowData());
	}

	/**
	 */
	protected abstract void doDefaultItem(final T model);

	/**
	 */
	public abstract T getDefault();
}