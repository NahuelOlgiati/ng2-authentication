package com.ebizlink.pandora2.core.msg.enumeration;

public enum DatabaseMsgEnum
{
	RECORD_NOT_FOUND,
	RECORD_NOT_UPDATED,
	RECORD_NOT_DELETED;
}