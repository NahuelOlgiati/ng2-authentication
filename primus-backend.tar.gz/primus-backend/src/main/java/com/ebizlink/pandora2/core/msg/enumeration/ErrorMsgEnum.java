package com.ebizlink.pandora2.core.msg.enumeration;

public enum ErrorMsgEnum
{
	GENERAL,
	NOT_SUPPORTED,
	NOT_IMPLEMENTED;
}