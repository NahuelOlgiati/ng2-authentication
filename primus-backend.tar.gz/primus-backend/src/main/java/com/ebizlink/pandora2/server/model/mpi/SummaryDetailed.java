package com.ebizlink.pandora2.server.model.mpi;

import java.util.List;
import com.ebizlink.pandora2.web.component.DetailData;

public interface SummaryDetailed extends Detailed
{
	/**
	 */
	public abstract List<DetailData> getSummaryDetailList();
}
