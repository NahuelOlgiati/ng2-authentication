package com.ebizlink.pandora2.server.model.support;

import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class QueryResult implements Serializable
{
}