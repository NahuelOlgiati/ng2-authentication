package com.primus.rest.app;

public enum RoleEnum
{
	ADMIN;
}