package com.primus.rest.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.HttpHeaders;
import org.jboss.resteasy.spi.CorsHeaders;

public class CorsFilter implements Filter
{
	/**
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException
	{
	}

	/**
	 */
	@Override
	public void destroy()
	{
	}

	/**
	 */
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException
	{
		if (servletResponse instanceof HttpServletResponse)
		{
			HttpServletResponse response = ((HttpServletResponse) servletResponse);
			response.addHeader(CorsHeaders.ACCESS_CONTROL_ALLOW_ORIGIN, "*");
			response.addHeader(CorsHeaders.ACCESS_CONTROL_ALLOW_HEADERS, "origin, content-type, accept, authorization, x-requested-with");
			response.addHeader(CorsHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
			response.addHeader(CorsHeaders.ACCESS_CONTROL_ALLOW_METHODS, "GET, POST, PUT, DELETE, OPTIONS, HEAD");
			response.addHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			response.addHeader(HttpHeaders.ACCEPT, "application/json");
		}
		filterChain.doFilter(servletRequest, servletResponse);
	}
}
