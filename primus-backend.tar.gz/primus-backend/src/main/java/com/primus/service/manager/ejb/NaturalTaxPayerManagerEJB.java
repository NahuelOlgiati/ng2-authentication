package com.primus.service.manager.ejb;

import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import com.ebizlink.pandora2.core.exception.BaseException;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.ejb.util.PredicateBuilder;
import com.ebizlink.pandora2.server.model.support.QueryHint;
import com.ebizlink.pandora2.web.util.QueryHintResult;
import com.primus.model.DocumentType;
import com.primus.model.NaturalTaxPayer;
import com.primus.model.composite.Document;
import com.primus.service.manager.local.NaturalTaxPayerManagerLocal;


@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class NaturalTaxPayerManagerEJB extends BaseTaxPayerManagerEJB<NaturalTaxPayer> implements NaturalTaxPayerManagerLocal
{
	/**
	 */
	@Override
	public Class<NaturalTaxPayer> getModelClass()
	{
		return NaturalTaxPayer.class;
	}

	/**
	 */
	@Override
	public QueryHintResult<NaturalTaxPayer> getQueryHintResult(final String description, final QueryHint queryHint)
	{
		QueryHintResult<NaturalTaxPayer> queryHintResult = null;
		try
		{
			final CriteriaBuilder cb = em.getCriteriaBuilder();
			final PredicateBuilder pb = new PredicateBuilder(cb);
			final CriteriaQuery<NaturalTaxPayer> cq = cb.createQuery(getModelClass());
			final Root<NaturalTaxPayer> naturalTaxPayer = cq.from(getModelClass());
//			final Path<String> lastName = naturalTaxPayer.get(NaturalTaxPayer_.lastName);
//			final Path<String> firstName = naturalTaxPayer.get(NaturalTaxPayer_.firstName);
//			final Path<Document> document = naturalTaxPayer.get("document");
//			final Path<String> documentNumber = document.get(Document_.documentNumber);
//			final List<Order> orderList = new ArrayList<Order>();
//
//			// Expressions.
//			cq.where(cb.or(pb.like(lastName, description), pb.like(firstName, description), pb.like(documentNumber, description)));
//			orderList.add(cb.asc(lastName));
//			orderList.add(cb.asc(firstName));
//			cq.orderBy(orderList);

			// Gets data.
			queryHintResult = getQueryHintResult(cq, queryHint);
		}
		catch (final Throwable t)
		{
			throw new EJBException(t.getMessage());
		}
		return queryHintResult;
	}

	/**
	 */
	@Override
	public List<NaturalTaxPayer> getNaturalTaxPayerByDocument(final Document document, final QueryHint queryHint)
	{
		List<NaturalTaxPayer> naturalTaxPayerList = null;
		try
		{
			final CriteriaBuilder cb = em.getCriteriaBuilder();
			final PredicateBuilder pb = new PredicateBuilder(cb);
			final CriteriaQuery<NaturalTaxPayer> cq = cb.createQuery(getModelClass());
			final Root<NaturalTaxPayer> naturalTaxPayer = cq.from(getModelClass());

//			final Path<Document> pd = naturalTaxPayer.get("document");
//			final Path<String> pdDocumentNumber = pd.get(Document_.documentNumber);
//			final Path<DocumentType> pdDocumentType = pd.get(Document_.documentType);
//			final Path<String> pdDocumentTypeDesc = pdDocumentType.get(DocumentType_.description);
//
//			final Path<Document> sd = naturalTaxPayer.get("secondaryDocument");
//			final Path<String> sdDocumentNumber = sd.get(Document_.documentNumber);
//			final Path<DocumentType> sdDocumentType = sd.get(Document_.documentType);
//			final Path<String> sdDocumentTypeDesc = sdDocumentType.get(DocumentType_.description);
//
//			// Expressions.
//			cq.distinct(Boolean.TRUE);
//			cq.where(cb.or(
//					cb.and(pb.equal(pdDocumentNumber, document.getDocumentNumber()),
//							pb.equal(pdDocumentTypeDesc, document.getDocumentType().getDescription())),
//					cb.and(pb.equal(sdDocumentNumber, document.getDocumentNumber()),
//							pb.equal(sdDocumentTypeDesc, document.getDocumentType().getDescription()))));

			// Gets data.
			naturalTaxPayerList = getList(cq, queryHint);
		}
		catch (final Throwable t)
		{
			throw new EJBException(t.getMessage());
		}
		return naturalTaxPayerList;
	}

	/**
	 */
	@Override
	protected void doBeforeAddUpdate(final NaturalTaxPayer model) throws BaseException
	{
		try
		{
			model.getDocument().valid();
		}
		catch (final Throwable t)
		{
			return;
		}

		if ((!CompareUtil.isEmpty(model.getSecondaryDocumentRO())) && (model.getDocument().equals(model.getSecondaryDocumentRO())))
		{
//			throw new ManagerException(DBSMsgHandler.getMsg(NaturalTaxPayerManagerEJB.class, "documentEqualToSecondaryDocument"));
		}

		if (getDuplicatedException(model.getDocument(), model))
		{
//			throw new ManagerException(DBSMsgHandler.getMsg(NaturalTaxPayerManagerEJB.class, "duplicatedDocument"));
		}

		if (getDuplicatedException(model.getSecondaryDocumentRO(), model))
		{
//			throw new ManagerException(DBSMsgHandler.getMsg(NaturalTaxPayerManagerEJB.class, "duplicatedSecondaryDocument"));
		}

		super.doBeforeAddUpdate(model);
	}

	/**
	 */
	@Override
	public boolean getDuplicatedException(final Document document, final NaturalTaxPayer naturalTaxPayer)
	{
		Boolean duplicated = Boolean.FALSE;
		try
		{
			if (!CompareUtil.isEmpty(document))
			{
				final List<NaturalTaxPayer> ntpList = getNaturalTaxPayerByDocument(document, new QueryHint(0, 1));

				if (!CompareUtil.isEmpty(ntpList))
				{
					duplicated = !ntpList.contains(naturalTaxPayer);
				}
			}
		}
		catch (final Throwable t)
		{
			throw new EJBException(t.getMessage());
		}
		return duplicated;
	}
}