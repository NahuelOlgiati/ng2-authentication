package com.primus.app;

import java.io.File;

import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.wildfly.swarm.Swarm;
import org.wildfly.swarm.datasources.DatasourcesFraction;
import org.wildfly.swarm.jaxrs.JAXRSArchive;

import com.primus.rest.app.RestApp;

public class Main {

	static String driverModule;

	public static void main(String[] args) throws Exception {

//		final JAXRSArchive war = ShrinkWrap.createFromZipFile(JAXRSArchive.class,
//				new File("./target/primus-backend.war"));

		// final WebArchive war =
		// ShrinkWrap.create(MavenImporter.class).loadPomFromFile("pom.xml").importBuildOutput().as(WebArchive.class);
		// war.addClass(ArquillianEJBContainerTest.class);

		driverModule = "org.postgresql";

		Swarm swarm = new Swarm();
		swarm.fraction(datasourceWithPostgresql());

		JAXRSArchive deployment = ShrinkWrap.create(JAXRSArchive.class);
		deployment.addClass(RestApp.class);
		// deployment.addClass(DocumentTypeEndPoint.class);
		// deployment.addClass(BaseEJB.class);
		// deployment.addClass(BaseModel.class);
		// deployment.addClass(Manageable.class);
		// deployment.addPackage("com.ebizlink.pandora2");
		// deployment.addPackage("com.primus");
		// deployment.addAllDependencies();

		// Deploy your app
		swarm.start().deploy(deployment);

	}

	private static DatasourcesFraction datasourceWithPostgresql() {
		return new DatasourcesFraction().jdbcDriver("org.postgresql", (d) -> {
			d.driverClassName("org.postgresql.Driver");
			d.xaDatasourceClass("org.postgresql.xa.PGXADataSource");
			d.driverModuleName("org.postgresql");
		}).dataSource("villegasDS", (ds) -> {
			ds.driverName("org.postgresql");
			ds.connectionUrl("jdbc:postgresql://localhost:5433/villegas");
			ds.userName("villegas");
			ds.password("villegas");
		});
	}
}