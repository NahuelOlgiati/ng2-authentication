package com.tallion.villegas.tax.portal.rest.filter;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Priority;
import javax.annotation.security.DenyAll;
import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;
import org.jboss.resteasy.core.ResourceMethodInvoker;
import org.jboss.resteasy.util.Base64;

@Provider
@Priority(Priorities.AUTHORIZATION)
public class SecurityFilter implements ContainerRequestFilter
{
	public static final String RESOURCE_METHOD_INVOKER = "org.jboss.resteasy.core.ResourceMethodInvoker";

	/**
	 */
	@Override
	public void filter(ContainerRequestContext requestContext)
	{
		ResourceMethodInvoker methodInvoker = (ResourceMethodInvoker) requestContext.getProperty(RESOURCE_METHOD_INVOKER);
		Method method = methodInvoker.getMethod();

		// Access allowed for all
		if (method.isAnnotationPresent(PermitAll.class))
		{
			return;
		}

		// Access denied for all
		if (method.isAnnotationPresent(DenyAll.class))
		{
			requestContext.abortWith(Response.status(Status.FORBIDDEN).build());
			return;
		}

		// Verify user access
		if (method.isAnnotationPresent(RolesAllowed.class))
		{
			// If no authorization information present then block access
			String authorization = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
			if (authorization == null || authorization.isEmpty())
			{
				requestContext.abortWith(Response.status(Status.UNAUTHORIZED).build());
				return;
			}

			// Get encoded username and password and decode
			String[] userAndPassword;
			try
			{
				byte[] decodedHeader = Base64.decode(authorization.replace("Basic ", ""));
				userAndPassword = new String(decodedHeader, StandardCharsets.UTF_8).split(":");
			}
			catch (IOException e)
			{
				requestContext.abortWith(Response.status(Status.INTERNAL_SERVER_ERROR).build());
				return;
			}

			RolesAllowed rolesAnnotation = method.getAnnotation(RolesAllowed.class);
			List<String> requiredRoles = Arrays.asList(rolesAnnotation.value());
			final String username = userAndPassword[0];
			final String password = userAndPassword[1];
			if (!isUserAllowed(username, password, requiredRoles))
			{
				requestContext.abortWith(Response.status(Status.UNAUTHORIZED).build());
				return;
			}
		}
	}

	/**
	 */
	private boolean isUserAllowed(final String username, final String password, final List<String> rolesSet)
	{
		boolean isAllowed = false;

		String userRole = "ADMIN";

		if (rolesSet.contains(userRole))
		{
			isAllowed = true;
		}
		return isAllowed;
	}
}