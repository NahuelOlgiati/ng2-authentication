package com.tallion.villegas.tax.portal.rest.endpoint;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.ebizlink.adonis.config.model.DocumentType;
import com.ebizlink.adonis.config.service.manager.local.DocumentTypeManagerLocal;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.ebizlink.pandora2.server.exception.ManagerException;
import com.ebizlink.pandora2.server.model.support.QueryHint;
import com.tallion.villegas.tax.portal.rest.annotation.Authenticated;

@Stateless
@Path("/documentType")
public class DocumentTypeEndPoint
{
	@EJB
	private DocumentTypeManagerLocal documentTypeML;

	@Authenticated
	@RolesAllowed("ADMIN")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public DocumentType[] get()
	{
		return documentTypeML.getQueryHintResult("", new QueryHint(0, Integer.MAX_VALUE)).getQueryList().toArray(new DocumentType[0]);
	}

	@PermitAll
	@GET
	@Path("/get:{id:[0-9][0-9]*}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response findById(@PathParam("id") Long id)
	{
		final DocumentType documentType = documentTypeML.get(id);
		if (CompareUtil.isEmpty(documentType))
		{
			return Response.status(Status.NOT_FOUND).build();
		}
		return Response.ok(documentType).build();
	}

	@PermitAll
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public Response create(DocumentType documentType)
	{
		Response r = null;
		try
		{
			documentTypeML.save(documentType);
		}
		catch (ManagerException e)
		{
			System.out.println("exception in create " + e);
			r = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
		return r;
	}

	@PermitAll
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public Response update(DocumentType documentType)
	{
		Response r = null;
		try
		{
			documentTypeML.save(documentType);
		}
		catch (ManagerException e)
		{
			System.out.println("exception in update " + e);
			r = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
		return r;
	}

	@PermitAll
	@DELETE
	@Path("/{id:[0-9][0-9]*}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response deleteById(@PathParam("id") Long id)
	{
		Response r = null;
		try
		{
			documentTypeML.delete(id);
			r = Response.ok().build();
		}
		catch (Exception e)
		{
			System.out.println("exception in create " + e);
			r = Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
		return r;
	}
}
