package com.tallion.villegas.tax.portal.rest.app;

import java.security.Principal;
import java.util.Date;
import com.ebizlink.adonis.admin.model.mpa.User;

/**
 */
public class UserPrincipal implements Principal
{
	private User user;
	private Date signinDate;

	/**
	 */
	public UserPrincipal(User user, Date signinDate)
	{
		this.user = user;
		this.signinDate = signinDate;
	}

	/**
	 */
	public User getUser()
	{
		return user;
	}

	/**
	 */
	public void setUser(User user)
	{
		this.user = user;
	}

	/**
	 */
	public Date getSigninDate()
	{
		return signinDate;
	}

	/**
	 */
	public void setSigninDate(Date signinDate)
	{
		this.signinDate = signinDate;
	}

	/**
	 */
	@Override
	public String getName()
	{
		return getUser().getUserName();
	}
}