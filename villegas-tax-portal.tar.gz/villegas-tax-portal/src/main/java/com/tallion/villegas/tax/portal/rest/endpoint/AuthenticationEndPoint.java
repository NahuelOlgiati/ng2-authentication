package com.tallion.villegas.tax.portal.rest.endpoint;

import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;
import com.ebizlink.adonis.admin.model.mpa.User;
import com.ebizlink.adonis.admin.service.manager.local.UserManagerLocal;
import com.ebizlink.pandora2.core.util.CompareUtil;
import com.tallion.villegas.tax.portal.rest.app.RestAuthenticationContext;

@Stateless
@Path("/authentication")
public class AuthenticationEndPoint
{
	@Inject
	private RestAuthenticationContext authenticationCTX;

	@EJB
	private UserManagerLocal userML;

	@PermitAll
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response authenticate(@FormParam("email") String email, @FormParam("password") String password, @Context HttpServletRequest servletRequest)
	{
		try
		{
			servletRequest.login("villegas", "a123dmin");

			final User user = userML.getFULL("villegas");

			if (CompareUtil.isEmpty(user))
			{
				return Response.status(Response.Status.NOT_FOUND).build();
			}

			// Authenticate the user using the credentials provided
			String token = authenticationCTX.register(user);
			String successResponse = successResponse(token);
			return Response.ok(successResponse).build();
		}
		catch (ServletException e)
		{
			return Response.status(Response.Status.UNAUTHORIZED).build();
		}
		catch (Exception e)
		{
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	/**
	 */
	@SuppressWarnings("unchecked")
	private String successResponse(String token)
	{
		JSONObject response = new JSONObject();
		response.put("success", true);
		response.put("token", token);
		return response.toJSONString();
	}
}