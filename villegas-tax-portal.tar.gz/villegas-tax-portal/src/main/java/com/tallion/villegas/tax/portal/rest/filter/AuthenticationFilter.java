
package com.tallion.villegas.tax.portal.rest.filter;

import java.io.IOException;
import java.security.Principal;
import javax.annotation.Priority;
import javax.inject.Inject;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.ext.Provider;
import com.tallion.villegas.tax.portal.rest.annotation.Authenticated;
import com.tallion.villegas.tax.portal.rest.app.RestAuthenticationContext;
import com.tallion.villegas.tax.portal.rest.app.UserPrincipal;

@Provider
@Authenticated
@Priority(Priorities.AUTHENTICATION)
public class AuthenticationFilter implements ContainerRequestFilter
{
	@Inject
	private RestAuthenticationContext auth;

	/**
	 */
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException
	{
		// If no authorization information present then block access
		String authorization = requestContext.getHeaderString(HttpHeaders.AUTHORIZATION);
		if (authorization == null || authorization.isEmpty())
		{
			requestContext.abortWith(Response.status(Status.UNAUTHORIZED).build());
			return;
		}

		String token = authorization;
		final UserPrincipal authenticatedUser = auth.getAuthenticatedUser(token);
		if (authenticatedUser == null)
		{
			requestContext.abortWith(Response.status(Status.UNAUTHORIZED).build());
			return;
		}
		requestContext.setSecurityContext(new SecurityContext()
		{
			@Override
			public boolean isUserInRole(String role)
			{
				return false;
			}

			@Override
			public boolean isSecure()
			{
				return false;
			}

			@Override
			public Principal getUserPrincipal()
			{
				return authenticatedUser;
			}

			@Override
			public String getAuthenticationScheme()
			{
				return null;
			}
		});
	}
}
