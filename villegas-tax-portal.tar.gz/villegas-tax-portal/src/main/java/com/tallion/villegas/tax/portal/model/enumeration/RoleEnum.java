package com.tallion.villegas.tax.portal.model.enumeration;

public enum RoleEnum
{
}