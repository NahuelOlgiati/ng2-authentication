package com.tallion.villegas.tax.portal.component.controller;

import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import com.ebizlink.adonis.admin.web.component.controller.BasePermitInitilizer;
import com.tallion.villegas.tax.web.model.enumeration.ExclusionRoleEnum;

@ManagedBean(eager = true)
@ApplicationScoped
@SuppressWarnings("serial")
public class PermitInitilizer extends BasePermitInitilizer
{
	/**
	 */
	@Override
	public List<Class<?>> getRoleEnumClasses()
	{
		final List<Class<?>> list = new ArrayList<Class<?>>();
		list.add(com.ebizlink.pandora2.web.model.enumeration.RoleEnum.class);
		list.add(com.ebizlink.adonis.admin.web.model.enumeration.RoleEnum.class);
		list.add(com.ebizlink.adonis.config.web.model.enumeration.RoleEnum.class);
		list.add(com.ebizlink.adonis.erp.web.model.enumeration.RoleEnum.class);
		list.add(com.tallion.osiris.tax.portal.model.enumeration.RoleEnum.class);
		list.add(com.tallion.osiris.tax.web.model.enumeration.RoleEnum.class);
		list.add(com.tallion.osiris.taxfieldjob.web.model.enumeration.RoleEnum.class);
		list.add(com.tallion.villegas.tax.portal.model.enumeration.RoleEnum.class);
		list.add(com.tallion.villegas.tax.web.model.enumeration.RoleEnum.class);
		return list;
	}

	/**
	 */
	@Override
	public List<Class<?>> getExlcusionRoleEnumClasses()
	{
		final List<Class<?>> list = new ArrayList<Class<?>>();
		list.add(ExclusionRoleEnum.class);
		return list;
	}
}